﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TelasTCC.DB.Produtos;

namespace TelasTCC
{
    public partial class frmCadProdutos : Form
    {
        public frmCadProdutos()
        {
            InitializeComponent();
        }


        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            if (txtNome.Text == "" || txtValor.Text == "" || txtDescricao.Text == "")
            {
                MessageBox.Show("Preencha todos os campos!!", "Atenção");
            }
            else
            {
                double valor = Convert.ToDouble(txtValor.Text);
                if (valor > 1000)
                {
                    if (MessageBox.Show("Deseja realmente cadastrar um valor acima de 1000?", "Atenção", MessageBoxButtons.YesNo) == DialogResult.No)
                    {
                        txtValor.Focus();
                    }
                }
                else
                {
                    ProdutosDTO dto = new ProdutosDTO();
                    if (txtNome.Text != null && txtDescricao.Text != null && txtValor.Text != null)
                    {
                        dto.Nome = txtNome.Text;
                        dto.Valor = Convert.ToString(valor);
                        dto.Descricao = txtDescricao.Text;

                        MessageBox.Show("Produto cadastrado.");
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Não foi possivel cadastrar.");
                        txtNome.Clear();
                        txtDescricao.Clear();
                        txtValor.Clear();
                        txtDescricao.Clear();
                        txtValor.Clear();
                        txtNome.Clear();
                    }
                    ProdutosBusiness business = new ProdutosBusiness();
                    business.Salvar(dto);
                }
            }
        }

        private void txtNome_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar))
            {
                MessageBox.Show("Digite somente letras");
                e.Handled = true;
            }
        }

        private void txtDescricao_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar))
            {
                MessageBox.Show("Digite somente letras");
                e.Handled = true;
            }
        }

        private void txtValor_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                MessageBox.Show("Digite somente números");
                e.Handled = true;
            }
        }
    }
}
﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TelasTCC.DB.Base;

namespace TelasTCC.DB.Pizzaria
{
    class PizzariaDatabase
    {
        public int Salvar(PizzariaDTO dto)
        {
            string script = @"INSERT INTO itenspedido(`qtdeProduto`,`Produto_IdProduto`,`valorItem`,`pedido`) VALUES(@qtdeProduto,@Produto_IdProduto,@valorItem,@pedido)";

            List<MySqlParameter> parms = new List<MySqlParameter>();
            parms.Add(new MySqlParameter("Produto_IdProduto", dto.IdProduto));
            parms.Add(new MySqlParameter("qtdeProduto", dto.QuantidadeProduto));
            parms.Add(new MySqlParameter("valorItem", float.Parse(dto.Preco) * float.Parse(dto.QuantidadeProduto)));
            parms.Add(new MySqlParameter("pedido", int.Parse(dto.idPedido) + 1));

            Database db = new Database();
            return db.ExecuteInsetScriptWithPk(script, parms);
        }

        public int SalvarMeia(PizzariaDTO dto)
        {
            string script = @"INSERT INTO itenspedido(`qtdeProduto`,`Produto_IdProduto`,`valorItem`,`pedido`,`idMeia`) VALUES(@qtdeProduto,@Produto_IdProduto,@valorItem,@pedido,@idMeia)";

            List<MySqlParameter> parms = new List<MySqlParameter>();
            parms.Add(new MySqlParameter("Produto_IdProduto", dto.IdProduto));
            parms.Add(new MySqlParameter("qtdeProduto", dto.QuantidadeProduto));
            parms.Add(new MySqlParameter("valorItem", float.Parse(dto.Preco) * float.Parse(dto.QuantidadeProduto)));
            parms.Add(new MySqlParameter("pedido", int.Parse(dto.idPedido) + 1));
            try
            {
                parms.Add(new MySqlParameter("idMeia", int.Parse(dto.IdMeia) + 1));
            }
            catch (Exception)
            {
                parms.Add(new MySqlParameter("idMeia", 1));
            }
            Database db = new Database();
            return db.ExecuteInsetScriptWithPk(script, parms);
        }

        public DataTable Listar(string tipo)
        {
            string script = "SELECT `nome` FROM `produto` WHERE `descricao` = '" + tipo + "';";

            Connection conn = new Connection();

            MySqlCommand com = new MySqlCommand();
            com.Connection = conn.Create();
            com.CommandText = script;

            MySqlDataReader reader = com.ExecuteReader();
            DataTable dataTable = new DataTable();
            dataTable.Load(reader);

            return dataTable;
        }

        public string ListarProduto(string campo, string produto)
        {
            string script = "SELECT `"+ campo + "` AS campo FROM `produto` WHERE `nome` = '" + produto + "';";

            List<MySqlParameter> parms = new List<MySqlParameter>();

            Database db = new Database();
            MySqlDataReader reader = db.ExecuteSelectScript(script, parms);

            List<PizzariaDTO> listar = new List<PizzariaDTO>();

            string senha = "";

            while (reader.Read())
            {
                PizzariaDTO dto = new PizzariaDTO();
                dto.IdProduto = reader.GetString("campo");

                senha = dto.IdProduto;
            }
            reader.Close();

            return senha;
        }// listarProduto e ListarValor
        
        public string ListarPedido()
        {
            string script = "SELECT MAX(`idPedido`) AS id FROM pedido";

            List<MySqlParameter> parms = new List<MySqlParameter>();

            Database db = new Database();
            MySqlDataReader reader = db.ExecuteSelectScript(script, parms);

            List<PizzariaDTO> listar = new List<PizzariaDTO>();

            string idPedido = "";

            while (reader.Read())
            {
                PizzariaDTO dto = new PizzariaDTO();
                dto.idPedido = reader.GetString("id");

                idPedido = dto.idPedido;
            }
            reader.Close();

            return idPedido;
        }

        public string ListarMeia()
        {
            string script = "SELECT MAX(`idMeia`) AS id FROM `itenspedido`";

            List<MySqlParameter> parms = new List<MySqlParameter>();

            Database db = new Database();
            MySqlDataReader reader = db.ExecuteSelectScript(script, parms);

            List<PizzariaDTO> listar = new List<PizzariaDTO>();

            string idPedido = "";

            while (reader.Read())
            {
                PizzariaDTO dto = new PizzariaDTO();
                try
                {
                    dto.idPedido = reader.GetString("id");
                    idPedido = dto.idPedido;
                }
                catch (Exception)
                {
                    dto.idPedido = "00.00";
                    idPedido = dto.idPedido;
                }
                
            }
            reader.Close();

            return idPedido;
        }

        public string ListarValorFinal(string valFinal)
        {
            int final = int.Parse(valFinal) + 1;
            string script = "SELECT SUM(`valorItem`) as total FROM itenspedido WHERE `pedido` = '" + final + "';";

            List<MySqlParameter> parms = new List<MySqlParameter>();

            Database db = new Database();
            MySqlDataReader reader = db.ExecuteSelectScript(script, parms);

            List<PizzariaDTO> listar = new List<PizzariaDTO>();

            string valorFinal = "";

            while (reader.Read())
            {
                PizzariaDTO dto = new PizzariaDTO();
                dto.ValorFinal = reader.GetString("total");

                valorFinal = dto.ValorFinal;
            }
            reader.Close();

            return valorFinal;
        }

        public int FinalizarPedido(PizzariaDTO dto)
        {
            string script = @"INSERT INTO pedido(`valor_pedido`,`ItensPedido_pedido`,`TipoPedido_idTipodePedido`) VALUES(@valor_pedido,@ItensPedido_pedido,@TipoPedido_idTipodePedido)";

            List<MySqlParameter> parms = new List<MySqlParameter>();

            parms.Add(new MySqlParameter("valor_pedido", float.Parse(dto.ValorFinal)));
            parms.Add(new MySqlParameter("ItensPedido_pedido", int.Parse(dto.idPedido) + 1));
            parms.Add(new MySqlParameter("TipoPedido_idTipodePedido", 1));

            Database db = new Database();
            return db.ExecuteInsetScriptWithPk(script, parms);
        }
    }
}

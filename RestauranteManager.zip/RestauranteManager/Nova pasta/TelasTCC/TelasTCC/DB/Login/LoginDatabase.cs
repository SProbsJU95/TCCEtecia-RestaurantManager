﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TelasTCC.DB.Base;

namespace TelasTCC.DB.Login
{
    class LoginDatabase
    { 
        public string ListarUsuario(string idUsu)
        {
            string script = "select usuario from funcionario where usuario = '" + idUsu + "';";

            List<MySqlParameter> parms = new List<MySqlParameter>();

            Database db = new Database();
            MySqlDataReader reader = db.ExecuteSelectScript(script, parms);

            List<LoginDTO> listaSenha = new List<LoginDTO>();

            string usuario = "";

            while (reader.Read())
            {
                LoginDTO dto = new LoginDTO();
                dto.Usuario = reader.GetString("usuario");

                usuario = dto.Usuario;
            }
            reader.Close();
            
            return usuario;
        }

        public string ListarSenha(string idUsu)
        {
            string script = "select senha from funcionario where usuario = '"+ idUsu+"';";
            
            List<MySqlParameter> parms = new List<MySqlParameter>();

            Database db = new Database();
            MySqlDataReader reader = db.ExecuteSelectScript(script, parms);

            List<LoginDTO> listaSenha = new List<LoginDTO>();

            string senha = "";

            while (reader.Read())
            {
                LoginDTO dto = new LoginDTO();
                dto.Senha = reader.GetString("senha");

                senha = dto.Senha;
            }
            reader.Close();

            return senha;
        }

        public string ListarFuncao(string idUsu)
        {
            string script = "select funcao from funcionario where usuario = '" + idUsu + "';";

            List<MySqlParameter> parms = new List<MySqlParameter>();

            Database db = new Database();
            MySqlDataReader reader = db.ExecuteSelectScript(script, parms);

            List<LoginDTO> listaSenha = new List<LoginDTO>();

            string funcao = "";

            while (reader.Read())
            {
                LoginDTO dto = new LoginDTO();
                dto.Funcao = reader.GetString("funcao");

                funcao = dto.Funcao;
            }
            reader.Close();

            return funcao;
        }
    }
}

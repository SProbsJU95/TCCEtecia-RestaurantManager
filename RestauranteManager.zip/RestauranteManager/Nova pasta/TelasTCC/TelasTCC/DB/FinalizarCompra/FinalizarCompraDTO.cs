﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TelasTCC.DB.FinalizarCompra
{
    class FinalizarCompraDTO
    {
        public string IdPedido { get; set; }
        public string Id { get; set; }

        public string Item { get; set; }
        public string ItemPreco { get; set; }
        public string ItemQuantidade { get; set; }

        public string ValorFinal { get; set; }
        public string FormaPagamento { get; set; }
        public string Bandeira { get; set; }
    }
}

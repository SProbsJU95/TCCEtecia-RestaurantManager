﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TelasTCC.DB.Base;

namespace TelasTCC.DB.Financeiro
{
    class FinanceiroDatabase
    {
        public List<FinanceiroDTO> Listar()
        {
            string script = "SELECT `CPF`,`nome`,`salario` FROM funcionario";

            List<MySqlParameter> parms = new List<MySqlParameter>();

            Database db = new Database();
            MySqlDataReader reader = db.ExecuteSelectScript(script, parms);

            List<FinanceiroDTO> lista = new List<FinanceiroDTO>();

            while (reader.Read())
            {
                FinanceiroDTO dto = new FinanceiroDTO();
                dto.Id = reader.GetString("CPF");
                dto.Nome = reader.GetString("nome");
                dto.Salario = reader.GetString("salario");

                float porcentagem = 0;
                if (float.Parse(dto.Salario) >= 5839.45){dto.Desconto = "11%";porcentagem = 11; }

                if (float.Parse(dto.Salario) <= 2919.72){dto.Desconto = "9%";porcentagem = 9; }

                if (float.Parse(dto.Salario) <= 1751.81){dto.Desconto = "8%";porcentagem = 8; }

                dto.SalarioFinal = ((float.Parse(dto.Salario) * porcentagem)/100).ToString();
                dto.SalarioFinal = (float.Parse(dto.Salario) - float.Parse(dto.SalarioFinal)).ToString();

                lista.Add(dto);
            }
            reader.Close();

            return lista;
        }

        public string ListarDataAtual(string data)
        {
            string script = data;

            List<MySqlParameter> parms = new List<MySqlParameter>();

            Database db = new Database();
            MySqlDataReader reader = db.ExecuteSelectScript(script, parms);

            List<FinanceiroDTO> listaSenha = new List<FinanceiroDTO>();

            string agora = "";

            while (reader.Read())
            {
                FinanceiroDTO dto = new FinanceiroDTO();
                dto.Data = reader.GetString("agora");

                agora = dto.Data;
            }
            reader.Close();

            return agora;
        }

        public string ListarTotalVendas(string data)
        {
            string script = data;

            List<MySqlParameter> parms = new List<MySqlParameter>();

            Database db = new Database();
            MySqlDataReader reader = db.ExecuteSelectScript(script, parms);

            List<FinanceiroDTO> listaSenha = new List<FinanceiroDTO>();

            string cartao = "";

            while (reader.Read())
            {
                FinanceiroDTO dto = new FinanceiroDTO();
                try
                {
                    dto.TotalVendas = reader.GetString("qtdeVendas");
                    cartao = dto.TotalVendas;
                }
                catch (Exception)
                {
                    dto.TotalVendas = "0";
                    cartao = dto.TotalVendas;
                }
            }
            reader.Close();
            
            return cartao;
        }
    }
}

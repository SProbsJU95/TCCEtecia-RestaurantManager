﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TelasTCC.DB.Financeiro
{
    class FinanceiroDTO
    {
        public string Id { get; set; }
        public string Nome { get; set; }
        public string Salario { get; set; }
        public string SalarioFinal { get; set; }
        public string Desconto { get; set; }
        public string Data { get; set; }
        public string TotalVendas { get; set; }
    }
}

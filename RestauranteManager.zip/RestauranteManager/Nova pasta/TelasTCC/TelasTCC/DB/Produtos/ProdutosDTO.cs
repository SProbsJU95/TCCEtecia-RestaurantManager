﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TelasTCC.DB.Produtos
{
    class ProdutosDTO
    {
        public string IdProduto { get; set; }
        public string Nome { get; set; }
        public string  Descricao { get; set; }
        public string Valor { get; set; }
    }
}

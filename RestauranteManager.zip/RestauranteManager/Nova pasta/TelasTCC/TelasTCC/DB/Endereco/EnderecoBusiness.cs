﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TelasTCC.DB.Endereco
{
    class EnderecoBusiness
    {
        public int SalvarEndereco(EnderecoDTO dto)
        {
            if (dto.Bairro == string.Empty)
                throw new ArgumentException("Bairro é obrigatório.");

            if (dto.Cep == string.Empty)
                throw new ArgumentException("CEP é obrigatório.");

            if (dto.Rua == string.Empty)
                throw new ArgumentException("Rua é obrigatória.");

            if (dto.Numero == string.Empty)
                throw new ArgumentException("Número da residência é obrigatório.");
            
            EnderecoDatabase db = new EnderecoDatabase();
            return db.Salvar(dto);
        }

        public int Editar(EnderecoDTO dto, string cpf)
        {
            /*if (dto.Nome == string.Empty)
                throw new ArgumentException("Nome é obrigatório.");

            if (dto.Celular== string.Empty)
                throw new ArgumentException("Telefone é obrigatório.");

            if (dto.num_residencia == string.Empty)
                throw new ArgumentException("Número da residencia é obrigatório.");*/

            EnderecoDatabase db = new EnderecoDatabase();
            return db.Editar(dto, cpf);// EDITARRR
        }
    }
}

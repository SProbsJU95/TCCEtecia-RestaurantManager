﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TelasTCC.DB.Base;
using TelasTCC.DB.Endereco;

namespace TelasTCC.DB.Usuario
{
    class UsuarioDatabase
    {
        public int Salvar(UsuarioDTO dto)
        {
            // testar a possibilidade de erro
            EnderecoDatabase database = new EnderecoDatabase();

            string enderecoFunc = database.AtribuirEndereco();
            // testar a possibilidade de erro

            string script = @"insert into funcionario(CPF, nome, telefone, salario, funcao, data_de_nascimento, senha, usuario, situacao, Endereco_idEndereco)values(@CPF, @nome, @telefone, @salario, @funcao, @data_de_nascimento, @senha, @usuario,@situacao, "+enderecoFunc+")";
            
            List<MySqlParameter> parms = new List<MySqlParameter>();
            parms.Add(new MySqlParameter("nome", dto.Nome));
            parms.Add(new MySqlParameter("usuario", dto.Usuario));
            parms.Add(new MySqlParameter("senha", dto.Senha));
            parms.Add(new MySqlParameter("telefone", dto.Celular));
            parms.Add(new MySqlParameter("CPF", dto.CPF));
            parms.Add(new MySqlParameter("salario", dto.Salario));
            parms.Add(new MySqlParameter("funcao", dto.Funcao));
            parms.Add(new MySqlParameter("situacao", dto.Situacao));
            parms.Add(new MySqlParameter("data_de_nascimento", dto.DataNascimento));//criar
            //parms.Add(new MySqlParameter("Endereco_idEndereco", dto.EnderecoFuncionario));//criar

            Database db = new Database();
            return db.ExecuteInsetScriptWithPk(script, parms);
        }

        public List<UsuarioDTO> Listar()
        {
            string script = "select * from tb_usuario";

            List<MySqlParameter> parms = new List<MySqlParameter>();

            Database db = new Database();
            MySqlDataReader reader = db.ExecuteSelectScript(script, parms);

            List<UsuarioDTO> lista = new List<UsuarioDTO>();

            while (reader.Read())
            {
                UsuarioDTO dto = new UsuarioDTO();
                dto.Id      = reader.GetInt32("id_usu");
                dto.Nome    = reader.GetString("nm_usu");
                dto.Usuario = reader.GetString("usuario_usu");
                dto.Senha   = reader.GetString("senha_usu");
                dto.Celular = reader.GetString("cel_usu");
                dto.CPF     = reader.GetString("cpf_usu");
                dto.Salario = reader.GetString("salario_usu");
                dto.Funcao  = reader.GetString("funcao_usu");
                dto.Situacao = reader.GetString("situacao");

                lista.Add(dto);
            }
            reader.Close();

            return lista;
        }
    }
}

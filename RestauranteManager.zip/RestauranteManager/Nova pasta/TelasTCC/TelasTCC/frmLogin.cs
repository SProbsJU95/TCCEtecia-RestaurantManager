﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TelasTCC.DB.Login;

namespace TelasTCC
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtUsuario.Text == string.Empty)
            {
                MessageBox.Show("Login é obrigatório!");
                txtUsuario.Focus();
            }
            else if (txtSenha.Text == string.Empty)
            {
                MessageBox.Show("Senha é obrigatória!");
                txtSenha.Focus();
            }
            else if (txtUsuario.Text != string.Empty && txtSenha.Text != string.Empty) {

                string usuForm = txtUsuario.Text;
                string SenhaForm = txtSenha.Text;

                LoginDatabase database = new LoginDatabase();

                string usu = database.ListarUsuario(usuForm);
                string pass = database.ListarSenha(usuForm);

                if (usuForm.Equals(usu) && SenhaForm.Equals(pass))
                {
                    Form menu = new frmMenu();
                    MessageBox.Show("Login realizado com sucesso");

                    string func = database.ListarFuncao(usuForm);
                    Funcao fun = new Funcao();
                    fun.SetFuncao(func);
                    /*Código de acompanhameno
                     *Funcao func = new Funcao();
                     *string aux = func.GetFuncao();*/

                    menu.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Falha no login");
                    txtUsuario.Text = string.Empty;
                    txtSenha.Text = string.Empty;
                    txtUsuario.Focus();
                }
            }
        }
        
        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            Form cad = new frmCad();
            cad.Show();
            this.Hide();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TelasTCC.DB.Cliente;
using TelasTCC.DB.Endereco;

namespace TelasTCC
{
    public partial class frmCadCliente : Form
    {
        public frmCadCliente()
        {
            InitializeComponent();
        }
        string cp , tel;
        private void btnCadCliente_Click(object sender, EventArgs e)
        {
            tel = txtTelefone.Text;
            cp = txtCep.Text;
            if (txtNome.Text == "" || txtTelefone.Text == "" || txtRua.Text == "" || txtBairro.Text == "" || txtNumero.Text == "" || txtCep.Text == "")
            {
                MessageBox.Show("Preenchar todos os Campos", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else if (tel.Length <10 || tel.Length>11)
            {
                MessageBox.Show("O telefone: " + tel + " é invalido \n Ex:1100000000 ");
            }
            else if (cp.Length != 8)
            {
                MessageBox.Show("CEP:" + cp + " invalido");
            }
            else
            {
                //Cadastro do Endereco do Cliente
                EnderecoDTO dtoE = new EnderecoDTO();
                dtoE.Bairro = txtBairro.Text;
                dtoE.Cep = txtCep.Text;
                dtoE.Complemento = txtComplemento.Text;
                dtoE.Numero = txtNumero.Text;
                dtoE.Rua = txtRua.Text;

                EnderecoBusiness businessE = new EnderecoBusiness();
                businessE.SalvarEndereco(dtoE);

                //Cadastro do Cliente
                ClienteDTO dto = new ClienteDTO();
                dto.Nome = txtNome.Text;
                dto.Telefone = txtTelefone.Text;

                ClienteBusiness business = new ClienteBusiness();
                business.Salvar(dto);

                MessageBox.Show("O cliente foi cadastrado com sucesso.");

                this.Close();
            }
        }

        private void txtTelefone_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                MessageBox.Show("Digite somente números");
                e.Handled = true;
            }
        }

        private void txtCep_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                MessageBox.Show("Digite somente números");
                e.Handled = true;
            }
        }

        private void txtNome_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar))
            {
                MessageBox.Show("Digite somente letras");
                e.Handled = true;
            }
        }

        private void txtBairro_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar))
            {
                MessageBox.Show("Digite somente letras");
                e.Handled = true;
            }
        }

        private void txtRua_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar))
            {
                MessageBox.Show("Digite somente letras");
                e.Handled = true;
            }
        }

        
    }
}
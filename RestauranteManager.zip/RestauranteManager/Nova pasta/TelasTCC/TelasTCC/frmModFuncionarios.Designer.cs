﻿namespace TelasTCC
{
    partial class frmModFuncionarios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbPizza = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dgvFuncionario = new System.Windows.Forms.DataGridView();
            this.Id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gbDados = new System.Windows.Forms.GroupBox();
            this.btnAtuali = new System.Windows.Forms.Button();
            this.lblInformacoes = new System.Windows.Forms.Label();
            this.btnConsultar = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.cbDados = new System.Windows.Forms.ComboBox();
            this.gbAtualizar = new System.Windows.Forms.GroupBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.txtNascimento = new System.Windows.Forms.MaskedTextBox();
            this.lblIdFunc = new System.Windows.Forms.Label();
            this.lblBairro = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtBairro = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtNumero = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtCep = new System.Windows.Forms.TextBox();
            this.lblRua = new System.Windows.Forms.Label();
            this.lblCep = new System.Windows.Forms.Label();
            this.lblNumero = new System.Windows.Forms.Label();
            this.lblCpf = new System.Windows.Forms.Label();
            this.lblNascimento = new System.Windows.Forms.Label();
            this.lblIdEndereco = new System.Windows.Forms.Label();
            this.lblSalario = new System.Windows.Forms.Label();
            this.lblSituacao = new System.Windows.Forms.Label();
            this.lblFuncao = new System.Windows.Forms.Label();
            this.lblTelefone = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtRua = new System.Windows.Forms.TextBox();
            this.txtCPF = new System.Windows.Forms.TextBox();
            this.txtTelefone = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtFuncao = new System.Windows.Forms.TextBox();
            this.txtSalario = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtSituacao = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnAtualizar = new System.Windows.Forms.Button();
            this.gbPizza.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFuncionario)).BeginInit();
            this.gbDados.SuspendLayout();
            this.gbAtualizar.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbPizza
            // 
            this.gbPizza.BackColor = System.Drawing.Color.Transparent;
            this.gbPizza.Controls.Add(this.label1);
            this.gbPizza.Controls.Add(this.dgvFuncionario);
            this.gbPizza.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.gbPizza.Location = new System.Drawing.Point(21, 34);
            this.gbPizza.Name = "gbPizza";
            this.gbPizza.Size = new System.Drawing.Size(738, 194);
            this.gbPizza.TabIndex = 3;
            this.gbPizza.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(17, -3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(148, 25);
            this.label1.TabIndex = 4;
            this.label1.Text = "Funcionários";
            // 
            // dgvFuncionario
            // 
            this.dgvFuncionario.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.dgvFuncionario.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvFuncionario.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Id,
            this.Column1,
            this.Column6,
            this.Column7,
            this.Column8,
            this.Column2});
            this.dgvFuncionario.Location = new System.Drawing.Point(16, 25);
            this.dgvFuncionario.Name = "dgvFuncionario";
            this.dgvFuncionario.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvFuncionario.Size = new System.Drawing.Size(708, 150);
            this.dgvFuncionario.TabIndex = 0;
            // 
            // Id
            // 
            this.Id.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.Id.DataPropertyName = "CPF";
            this.Id.HeaderText = "Id";
            this.Id.Name = "Id";
            this.Id.Visible = false;
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "Nome";
            this.Column1.HeaderText = "Nome";
            this.Column1.Name = "Column1";
            // 
            // Column6
            // 
            this.Column6.DataPropertyName = "Salario";
            this.Column6.HeaderText = "Salario";
            this.Column6.Name = "Column6";
            // 
            // Column7
            // 
            this.Column7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column7.DataPropertyName = "Funcao";
            this.Column7.HeaderText = "Função";
            this.Column7.Name = "Column7";
            // 
            // Column8
            // 
            this.Column8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column8.DataPropertyName = "Situacao";
            this.Column8.HeaderText = "Situação";
            this.Column8.Name = "Column8";
            // 
            // Column2
            // 
            this.Column2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column2.DataPropertyName = "Telefone";
            this.Column2.HeaderText = "Telefone";
            this.Column2.Name = "Column2";
            // 
            // gbDados
            // 
            this.gbDados.Controls.Add(this.btnAtuali);
            this.gbDados.Controls.Add(this.lblInformacoes);
            this.gbDados.Controls.Add(this.btnConsultar);
            this.gbDados.Controls.Add(this.label4);
            this.gbDados.Controls.Add(this.cbDados);
            this.gbDados.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbDados.Location = new System.Drawing.Point(21, 234);
            this.gbDados.Name = "gbDados";
            this.gbDados.Size = new System.Drawing.Size(738, 121);
            this.gbDados.TabIndex = 4;
            this.gbDados.TabStop = false;
            // 
            // btnAtuali
            // 
            this.btnAtuali.BackColor = System.Drawing.Color.White;
            this.btnAtuali.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAtuali.Location = new System.Drawing.Point(539, 28);
            this.btnAtuali.Name = "btnAtuali";
            this.btnAtuali.Size = new System.Drawing.Size(185, 34);
            this.btnAtuali.TabIndex = 15;
            this.btnAtuali.Text = "Fazer atualização";
            this.btnAtuali.UseVisualStyleBackColor = false;
            this.btnAtuali.Click += new System.EventHandler(this.btnAtuali_Click);
            // 
            // lblInformacoes
            // 
            this.lblInformacoes.AutoSize = true;
            this.lblInformacoes.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInformacoes.Location = new System.Drawing.Point(18, 87);
            this.lblInformacoes.Name = "lblInformacoes";
            this.lblInformacoes.Size = new System.Drawing.Size(113, 20);
            this.lblInformacoes.TabIndex = 14;
            this.lblInformacoes.Text = "lblInformacoes";
            // 
            // btnConsultar
            // 
            this.btnConsultar.BackColor = System.Drawing.Color.White;
            this.btnConsultar.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConsultar.Location = new System.Drawing.Point(358, 28);
            this.btnConsultar.Name = "btnConsultar";
            this.btnConsultar.Size = new System.Drawing.Size(153, 34);
            this.btnConsultar.TabIndex = 13;
            this.btnConsultar.Text = "Fazer consulta";
            this.btnConsultar.UseVisualStyleBackColor = false;
            this.btnConsultar.Click += new System.EventHandler(this.btnConsultar_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(18, 36);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(160, 20);
            this.label4.TabIndex = 12;
            this.label4.Text = "Dados do funcionário";
            // 
            // cbDados
            // 
            this.cbDados.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.cbDados.FormattingEnabled = true;
            this.cbDados.Items.AddRange(new object[] {
            "CPF",
            "Data de nascimento",
            "Endereço"});
            this.cbDados.Location = new System.Drawing.Point(184, 33);
            this.cbDados.Name = "cbDados";
            this.cbDados.Size = new System.Drawing.Size(145, 28);
            this.cbDados.TabIndex = 11;
            // 
            // gbAtualizar
            // 
            this.gbAtualizar.Controls.Add(this.label15);
            this.gbAtualizar.Controls.Add(this.label14);
            this.gbAtualizar.Controls.Add(this.txtNascimento);
            this.gbAtualizar.Controls.Add(this.lblIdFunc);
            this.gbAtualizar.Controls.Add(this.lblBairro);
            this.gbAtualizar.Controls.Add(this.label11);
            this.gbAtualizar.Controls.Add(this.txtBairro);
            this.gbAtualizar.Controls.Add(this.label13);
            this.gbAtualizar.Controls.Add(this.txtNumero);
            this.gbAtualizar.Controls.Add(this.label12);
            this.gbAtualizar.Controls.Add(this.txtCep);
            this.gbAtualizar.Controls.Add(this.lblRua);
            this.gbAtualizar.Controls.Add(this.lblCep);
            this.gbAtualizar.Controls.Add(this.lblNumero);
            this.gbAtualizar.Controls.Add(this.lblCpf);
            this.gbAtualizar.Controls.Add(this.lblNascimento);
            this.gbAtualizar.Controls.Add(this.lblIdEndereco);
            this.gbAtualizar.Controls.Add(this.lblSalario);
            this.gbAtualizar.Controls.Add(this.lblSituacao);
            this.gbAtualizar.Controls.Add(this.lblFuncao);
            this.gbAtualizar.Controls.Add(this.lblTelefone);
            this.gbAtualizar.Controls.Add(this.lblNome);
            this.gbAtualizar.Controls.Add(this.label10);
            this.gbAtualizar.Controls.Add(this.label9);
            this.gbAtualizar.Controls.Add(this.label8);
            this.gbAtualizar.Controls.Add(this.txtRua);
            this.gbAtualizar.Controls.Add(this.txtCPF);
            this.gbAtualizar.Controls.Add(this.txtTelefone);
            this.gbAtualizar.Controls.Add(this.label7);
            this.gbAtualizar.Controls.Add(this.label6);
            this.gbAtualizar.Controls.Add(this.txtFuncao);
            this.gbAtualizar.Controls.Add(this.txtSalario);
            this.gbAtualizar.Controls.Add(this.label3);
            this.gbAtualizar.Controls.Add(this.label5);
            this.gbAtualizar.Controls.Add(this.txtSituacao);
            this.gbAtualizar.Controls.Add(this.txtNome);
            this.gbAtualizar.Controls.Add(this.label2);
            this.gbAtualizar.Controls.Add(this.btnAtualizar);
            this.gbAtualizar.Enabled = false;
            this.gbAtualizar.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbAtualizar.Location = new System.Drawing.Point(783, 31);
            this.gbAtualizar.Name = "gbAtualizar";
            this.gbAtualizar.Size = new System.Drawing.Size(525, 324);
            this.gbAtualizar.TabIndex = 5;
            this.gbAtualizar.TabStop = false;
            this.gbAtualizar.Text = "Atualizar";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold);
            this.label15.Location = new System.Drawing.Point(8, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(105, 25);
            this.label15.TabIndex = 5;
            this.label15.Text = "Atualizar";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(123, 298);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(116, 18);
            this.label14.TabIndex = 55;
            this.label14.Text = "YYYY/MM/DD";
            // 
            // txtNascimento
            // 
            this.txtNascimento.Location = new System.Drawing.Point(118, 268);
            this.txtNascimento.Mask = "0000/00/00";
            this.txtNascimento.Name = "txtNascimento";
            this.txtNascimento.Size = new System.Drawing.Size(145, 27);
            this.txtNascimento.TabIndex = 6;
            this.txtNascimento.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals;
            this.txtNascimento.ValidatingType = typeof(System.DateTime);
            // 
            // lblIdFunc
            // 
            this.lblIdFunc.AutoSize = true;
            this.lblIdFunc.Location = new System.Drawing.Point(35, 28);
            this.lblIdFunc.Name = "lblIdFunc";
            this.lblIdFunc.Size = new System.Drawing.Size(23, 18);
            this.lblIdFunc.TabIndex = 53;
            this.lblIdFunc.Text = "id";
            this.lblIdFunc.Visible = false;
            // 
            // lblBairro
            // 
            this.lblBairro.AutoSize = true;
            this.lblBairro.Location = new System.Drawing.Point(455, 28);
            this.lblBairro.Name = "lblBairro";
            this.lblBairro.Size = new System.Drawing.Size(18, 18);
            this.lblBairro.TabIndex = 52;
            this.lblBairro.Text = "b";
            this.lblBairro.Visible = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(293, 158);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(56, 18);
            this.label11.TabIndex = 51;
            this.label11.Text = "Bairro";
            // 
            // txtBairro
            // 
            this.txtBairro.Location = new System.Drawing.Point(355, 155);
            this.txtBairro.Name = "txtBairro";
            this.txtBairro.Size = new System.Drawing.Size(145, 27);
            this.txtBairro.TabIndex = 10;
            this.txtBairro.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBairro_KeyPress);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(278, 122);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(71, 18);
            this.label13.TabIndex = 49;
            this.label13.Text = "Numero";
            // 
            // txtNumero
            // 
            this.txtNumero.Location = new System.Drawing.Point(355, 119);
            this.txtNumero.Name = "txtNumero";
            this.txtNumero.Size = new System.Drawing.Size(145, 27);
            this.txtNumero.TabIndex = 9;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(310, 89);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(39, 18);
            this.label12.TabIndex = 47;
            this.label12.Text = "CEP";
            // 
            // txtCep
            // 
            this.txtCep.Location = new System.Drawing.Point(355, 86);
            this.txtCep.Name = "txtCep";
            this.txtCep.Size = new System.Drawing.Size(145, 27);
            this.txtCep.TabIndex = 8;
            this.txtCep.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCep_KeyPress);
            // 
            // lblRua
            // 
            this.lblRua.AutoSize = true;
            this.lblRua.Location = new System.Drawing.Point(368, 28);
            this.lblRua.Name = "lblRua";
            this.lblRua.Size = new System.Drawing.Size(14, 18);
            this.lblRua.TabIndex = 45;
            this.lblRua.Text = "r";
            this.lblRua.Visible = false;
            // 
            // lblCep
            // 
            this.lblCep.AutoSize = true;
            this.lblCep.Location = new System.Drawing.Point(389, 28);
            this.lblCep.Name = "lblCep";
            this.lblCep.Size = new System.Drawing.Size(26, 18);
            this.lblCep.TabIndex = 44;
            this.lblCep.Text = "c2";
            this.lblCep.Visible = false;
            // 
            // lblNumero
            // 
            this.lblNumero.AutoSize = true;
            this.lblNumero.Location = new System.Drawing.Point(421, 28);
            this.lblNumero.Name = "lblNumero";
            this.lblNumero.Size = new System.Drawing.Size(28, 18);
            this.lblNumero.TabIndex = 43;
            this.lblNumero.Text = "n3";
            this.lblNumero.Visible = false;
            // 
            // lblCpf
            // 
            this.lblCpf.AutoSize = true;
            this.lblCpf.Location = new System.Drawing.Point(189, 28);
            this.lblCpf.Name = "lblCpf";
            this.lblCpf.Size = new System.Drawing.Size(16, 18);
            this.lblCpf.TabIndex = 42;
            this.lblCpf.Text = "c";
            this.lblCpf.Visible = false;
            // 
            // lblNascimento
            // 
            this.lblNascimento.AutoSize = true;
            this.lblNascimento.Location = new System.Drawing.Point(211, 28);
            this.lblNascimento.Name = "lblNascimento";
            this.lblNascimento.Size = new System.Drawing.Size(28, 18);
            this.lblNascimento.TabIndex = 41;
            this.lblNascimento.Text = "n2";
            this.lblNascimento.Visible = false;
            // 
            // lblIdEndereco
            // 
            this.lblIdEndereco.AutoSize = true;
            this.lblIdEndereco.Location = new System.Drawing.Point(327, 28);
            this.lblIdEndereco.Name = "lblIdEndereco";
            this.lblIdEndereco.Size = new System.Drawing.Size(35, 18);
            this.lblIdEndereco.TabIndex = 40;
            this.lblIdEndereco.Text = "IdE";
            this.lblIdEndereco.Visible = false;
            // 
            // lblSalario
            // 
            this.lblSalario.AutoSize = true;
            this.lblSalario.Location = new System.Drawing.Point(85, 28);
            this.lblSalario.Name = "lblSalario";
            this.lblSalario.Size = new System.Drawing.Size(17, 18);
            this.lblSalario.TabIndex = 39;
            this.lblSalario.Text = "s";
            this.lblSalario.Visible = false;
            // 
            // lblSituacao
            // 
            this.lblSituacao.AutoSize = true;
            this.lblSituacao.Location = new System.Drawing.Point(109, 28);
            this.lblSituacao.Name = "lblSituacao";
            this.lblSituacao.Size = new System.Drawing.Size(27, 18);
            this.lblSituacao.TabIndex = 38;
            this.lblSituacao.Text = "s1";
            this.lblSituacao.Visible = false;
            // 
            // lblFuncao
            // 
            this.lblFuncao.AutoSize = true;
            this.lblFuncao.Location = new System.Drawing.Point(142, 28);
            this.lblFuncao.Name = "lblFuncao";
            this.lblFuncao.Size = new System.Drawing.Size(14, 18);
            this.lblFuncao.TabIndex = 37;
            this.lblFuncao.Text = "f";
            this.lblFuncao.Visible = false;
            // 
            // lblTelefone
            // 
            this.lblTelefone.AutoSize = true;
            this.lblTelefone.Location = new System.Drawing.Point(168, 28);
            this.lblTelefone.Name = "lblTelefone";
            this.lblTelefone.Size = new System.Drawing.Size(15, 18);
            this.lblTelefone.TabIndex = 36;
            this.lblTelefone.Text = "t";
            this.lblTelefone.Visible = false;
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(61, 28);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(18, 18);
            this.lblNome.TabIndex = 35;
            this.lblNome.Text = "n";
            this.lblNome.Visible = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(74, 235);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(38, 18);
            this.label10.TabIndex = 34;
            this.label10.Text = "CPF";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(8, 268);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(104, 18);
            this.label9.TabIndex = 33;
            this.label9.Text = "Nascimento";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(310, 57);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(39, 18);
            this.label8.TabIndex = 32;
            this.label8.Text = "Rua";
            // 
            // txtRua
            // 
            this.txtRua.Location = new System.Drawing.Point(355, 54);
            this.txtRua.Name = "txtRua";
            this.txtRua.Size = new System.Drawing.Size(145, 27);
            this.txtRua.TabIndex = 7;
            this.txtRua.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRua_KeyPress);
            // 
            // txtCPF
            // 
            this.txtCPF.Location = new System.Drawing.Point(118, 232);
            this.txtCPF.Name = "txtCPF";
            this.txtCPF.Size = new System.Drawing.Size(145, 27);
            this.txtCPF.TabIndex = 5;
            this.txtCPF.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCPF_KeyPress);
            // 
            // txtTelefone
            // 
            this.txtTelefone.Location = new System.Drawing.Point(118, 191);
            this.txtTelefone.Name = "txtTelefone";
            this.txtTelefone.Size = new System.Drawing.Size(145, 27);
            this.txtTelefone.TabIndex = 4;
            this.txtTelefone.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTelefone_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(35, 194);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 18);
            this.label7.TabIndex = 26;
            this.label7.Text = "Telefone";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(47, 161);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 18);
            this.label6.TabIndex = 25;
            this.label6.Text = "Função";
            // 
            // txtFuncao
            // 
            this.txtFuncao.Location = new System.Drawing.Point(118, 158);
            this.txtFuncao.Name = "txtFuncao";
            this.txtFuncao.Size = new System.Drawing.Size(145, 27);
            this.txtFuncao.TabIndex = 3;
            this.txtFuncao.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFuncao_KeyPress);
            // 
            // txtSalario
            // 
            this.txtSalario.Location = new System.Drawing.Point(118, 87);
            this.txtSalario.Name = "txtSalario";
            this.txtSalario.Size = new System.Drawing.Size(145, 27);
            this.txtSalario.TabIndex = 1;
            this.txtSalario.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSalario_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(49, 90);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 18);
            this.label3.TabIndex = 22;
            this.label3.Text = "Salario";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(58, 57);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 18);
            this.label5.TabIndex = 21;
            this.label5.Text = "Nome";
            // 
            // txtSituacao
            // 
            this.txtSituacao.Location = new System.Drawing.Point(118, 123);
            this.txtSituacao.Name = "txtSituacao";
            this.txtSituacao.Size = new System.Drawing.Size(145, 27);
            this.txtSituacao.TabIndex = 2;
            this.txtSituacao.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSituacao_KeyPress);
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(118, 54);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(145, 27);
            this.txtNome.TabIndex = 0;
            this.txtNome.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNome_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(34, 126);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 18);
            this.label2.TabIndex = 17;
            this.label2.Text = "Situação";
            // 
            // btnAtualizar
            // 
            this.btnAtualizar.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.btnAtualizar.Location = new System.Drawing.Point(300, 252);
            this.btnAtualizar.Name = "btnAtualizar";
            this.btnAtualizar.Size = new System.Drawing.Size(200, 34);
            this.btnAtualizar.TabIndex = 11;
            this.btnAtualizar.Text = "Concluir Atualização";
            this.btnAtualizar.UseVisualStyleBackColor = true;
            this.btnAtualizar.Click += new System.EventHandler(this.btnAtualizar_Click);
            // 
            // frmModFuncionarios
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(242)))), ((int)(((byte)(219)))));
            this.ClientSize = new System.Drawing.Size(775, 378);
            this.Controls.Add(this.gbAtualizar);
            this.Controls.Add(this.gbDados);
            this.Controls.Add(this.gbPizza);
            this.Name = "frmModFuncionarios";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Módulo de funcionarios";
            this.gbPizza.ResumeLayout(false);
            this.gbPizza.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFuncionario)).EndInit();
            this.gbDados.ResumeLayout(false);
            this.gbDados.PerformLayout();
            this.gbAtualizar.ResumeLayout(false);
            this.gbAtualizar.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbPizza;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgvFuncionario;
        private System.Windows.Forms.GroupBox gbDados;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbDados;
        private System.Windows.Forms.Label lblInformacoes;
        private System.Windows.Forms.Button btnConsultar;
        private System.Windows.Forms.Button btnAtuali;
        private System.Windows.Forms.GroupBox gbAtualizar;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtSituacao;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnAtualizar;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtRua;
        private System.Windows.Forms.TextBox txtCPF;
        private System.Windows.Forms.TextBox txtTelefone;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtFuncao;
        private System.Windows.Forms.TextBox txtSalario;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblSalario;
        private System.Windows.Forms.Label lblSituacao;
        private System.Windows.Forms.Label lblFuncao;
        private System.Windows.Forms.Label lblTelefone;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblCpf;
        private System.Windows.Forms.Label lblNascimento;
        private System.Windows.Forms.Label lblIdEndereco;
        private System.Windows.Forms.Label lblBairro;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtBairro;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtNumero;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtCep;
        private System.Windows.Forms.Label lblRua;
        private System.Windows.Forms.Label lblCep;
        private System.Windows.Forms.Label lblNumero;
        private System.Windows.Forms.Label lblIdFunc;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.MaskedTextBox txtNascimento;
        private System.Windows.Forms.Label label15;
    }
}